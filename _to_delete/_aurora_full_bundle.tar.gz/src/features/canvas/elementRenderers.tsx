import { useEffect, useMemo, useState } from 'react';
import { Group, Image as KonvaImage, Path, Rect, Text } from 'react-konva';
import type Konva from 'konva';
import { MIN_ELEMENT_SIZE, type ElementBox } from './constants';
import type { CanvasElement, ElementPatch, FrameElement, ImageElement, StrokeElement } from './elements';
import { strokePathData } from './freehand';
import { useSignedUrl } from './useSignedUrl';
import type { CanvasPalette } from './useCanvasPalette';

/**
 * Element renderers. Every element is a Konva <Group> positioned/rotated by its
 * transform box; strokes render their real perfect-freehand outline, while
 * text/image/media are still labelled placeholders (their bodies land in
 * P3.3–P3.5). The group carries id={element.id} so the stage's <Transformer>
 * attaches via stage.findOne('#id') and the eraser maps a hit back to its
 * element via findAncestor('.canvas-element').
 *
 * On drag/transform end we bake Konva's scale back into the model (resetting the
 * node scale to 1). A stroke has no inner geometry to stretch, so a resize is
 * baked into its sample points + width instead.
 */

type ElementChange = (id: string, patch: ElementPatch) => void;

interface ElementNodeProps {
  element: CanvasElement;
  /** Element can be dragged (select tool, editable, unlocked). */
  draggable: boolean;
  /** Clicking/tapping selects (select tool + editable) — off while drawing. */
  selectable: boolean;
  palette: CanvasPalette;
  /**
   * Called on click/tap. `addToSelection` is true when the user held Shift,
   * signalling that this element should be toggled in/out of a multi-selection
   * rather than replacing the current selection.
   */
  onSelect: (id: string, addToSelection: boolean) => void;
  onChange: ElementChange;
  /** Double-click/tap to edit (text boxes only); undefined for other types. */
  onRequestEdit?: (id: string) => void;
  /** Report the live transform box mid drag/resize so an HTML overlay can follow
   *  (text boxes only); null on gesture end. */
  onLiveChange?: (box: ElementBox | null) => void;
  /**
   * When provided, called instead of `onChange` on drag end. Used by the
   * canvas stage to batch all selected-element positions into one history commit
   * during a group drag (avoids one commit per element).
   */
  onGroupDragEnd?: (id: string, x: number, y: number) => void;
}

/** The element's current transform box, reading any in-flight Konva scale. */
function nodeBox(node: Konva.Node, element: CanvasElement): ElementBox {
  return {
    id: element.id,
    x: node.x(),
    y: node.y(),
    width: Math.max(MIN_ELEMENT_SIZE, element.width * Math.abs(node.scaleX())),
    height: Math.max(MIN_ELEMENT_SIZE, element.height * Math.abs(node.scaleY())),
    rotation: node.rotation(),
  };
}

export function ElementNode({
  element,
  draggable,
  selectable,
  palette,
  onSelect,
  onChange,
  onRequestEdit,
  onLiveChange,
  onGroupDragEnd,
}: ElementNodeProps) {
  // Hidden elements are completely absent from the Konva tree (no hit region,
  // no transformer handle, no render cost beyond the React reconciler check).
  if (element.visible === false) return null;

  const select = (e: Konva.KonvaEventObject<MouseEvent | TouchEvent>) => {
    if (!selectable) return;
    e.cancelBubble = true; // don't let the stage clear the selection
    const addToSelection = 'shiftKey' in e.evt && (e.evt as MouseEvent).shiftKey;
    onSelect(element.id, addToSelection);
  };

  const requestEdit = (e: Konva.KonvaEventObject<MouseEvent | TouchEvent>) => {
    if (!onRequestEdit) return;
    e.cancelBubble = true;
    onRequestEdit(element.id);
  };

  const handleDragMove = (e: Konva.KonvaEventObject<DragEvent>) => {
    onLiveChange?.(nodeBox(e.target, element));
  };

  const handleTransform = (e: Konva.KonvaEventObject<Event>) => {
    onLiveChange?.(nodeBox(e.target, element));
  };

  const handleDragEnd = (e: Konva.KonvaEventObject<DragEvent>) => {
    if (onGroupDragEnd) {
      // Group drag: the canvas stage accumulates all deltas and commits in one
      // history step. We report our final position and skip onChange.
      onGroupDragEnd(element.id, e.target.x(), e.target.y());
    } else {
      onChange(element.id, { x: e.target.x(), y: e.target.y() });
    }
    onLiveChange?.(null);
  };

  const handleTransformEnd = (e: Konva.KonvaEventObject<Event>) => {
    const node = e.target;
    const scaleX = node.scaleX();
    const scaleY = node.scaleY();
    node.scaleX(1);
    node.scaleY(1);

    const base = {
      x: node.x(),
      y: node.y(),
      width: Math.max(MIN_ELEMENT_SIZE, element.width * Math.abs(scaleX)),
      height: Math.max(MIN_ELEMENT_SIZE, element.height * Math.abs(scaleY)),
      rotation: node.rotation(),
    };

    // A stroke has no inner shape to stretch — bake the resize into its sample
    // points + width so the recomputed outline matches the new box.
    if (element.type === 'stroke') {
      const uniform = (Math.abs(scaleX) + Math.abs(scaleY)) / 2;
      onChange(element.id, {
        ...base,
        points: scaleStrokePoints(element.points, scaleX, scaleY),
        size: Math.max(0.5, element.size * uniform),
      });
      onLiveChange?.(null);
      return;
    }

    onChange(element.id, base);
    onLiveChange?.(null);
  };

  return (
    <Group
      id={element.id}
      name="canvas-element"
      x={element.x}
      y={element.y}
      rotation={element.rotation}
      draggable={draggable}
      onClick={select}
      onTap={select}
      onDblClick={requestEdit}
      onDblTap={requestEdit}
      onDragMove={onGroupDragEnd ? undefined : handleDragMove}
      onTransform={handleTransform}
      onDragEnd={handleDragEnd}
      onTransformEnd={handleTransformEnd}
    >
      <ElementVisual element={element} palette={palette} />
    </Group>
  );
}

/** Scale a stroke's flattened `[x, y, pressure, …]` samples (pure). */
function scaleStrokePoints(points: number[], scaleX: number, scaleY: number): number[] {
  const out: number[] = [];
  for (let i = 0; i + 1 < points.length; i += 3) {
    out.push((points[i] ?? 0) * scaleX, (points[i + 1] ?? 0) * scaleY, points[i + 2] ?? 0.5);
  }
  return out;
}

/** The body for each element type. */
function ElementVisual({ element, palette }: { element: CanvasElement; palette: CanvasPalette }) {
  if (element.type === 'stroke') {
    return <StrokeVisual element={element} />;
  }

  const { width, height } = element;

  // A text box renders ONLY its background rect here — the rect is the hit /
  // transform target, while the formatted text itself is drawn by the HTML
  // TextLayer overlay (Konva can't render rich text). Dashed while empty.
  if (element.type === 'text') {
    const isEmpty = element.text.trim().length === 0;
    // Borderless: the box itself is invisible (a transparent-but-hittable rect so
    // it can still be selected / moved / transformed); only an EMPTY box shows a
    // faint dashed hint so you can find where to type. The text reads as plain
    // document text drawn by the HTML overlay.
    return (
      <Rect
        width={width}
        height={height}
        cornerRadius={8}
        fill="transparent"
        stroke={isEmpty ? palette.border : undefined}
        strokeWidth={isEmpty ? 1 : 0}
        dash={isEmpty ? [6, 5] : undefined}
        perfectDrawEnabled={false}
      />
    );
  }

  if (element.type === 'image') {
    return <ImageVisual element={element} palette={palette} />;
  }

  if (element.type === 'frame') {
    return <FrameVisual element={element} />;
  }

  // A table renders ONLY its background rect here — the rect is the hit /
  // transform / drag target, while the actual grid (borders, header tint,
  // cell text/inputs) is drawn by the HTML TableLayer overlay, the same
  // technique as the text box above (Konva can't host <input> cells).
  if (element.type === 'table') {
    return (
      <Rect
        width={width}
        height={height}
        cornerRadius={4}
        fill="transparent"
        perfectDrawEnabled={false}
      />
    );
  }

  // Media (audio/video): Konva renders ONLY the background rect — the hit /
  // transform / drag target. The actual <audio>/<video> player or embed <iframe>
  // is drawn by the HTML MediaLayer overlay (Konva can't host them), layered on
  // top via the same camera transform.
  return (
    <Rect
      width={width}
      height={height}
      cornerRadius={16}
      fill={palette.surface}
      stroke={palette.border}
      strokeWidth={1}
      perfectDrawEnabled={false}
    />
  );
}

/** A committed stroke: its filled perfect-freehand outline, recomputed from the
 *  stored samples so it stays crisp at any zoom. The filled path is the hit
 *  target (precise selection + erase); multiply gives the highlighter its look. */
function StrokeVisual({ element }: { element: StrokeElement }) {
  const data = useMemo(
    () =>
      strokePathData(element.points, {
        size: element.size,
        thinning: element.thinning,
        smoothing: element.smoothing,
        simulatePressure: element.simulatePressure,
      }),
    [element.points, element.size, element.thinning, element.smoothing, element.simulatePressure],
  );
  if (!data) return null;
  return (
    <Path
      data={data}
      fill={element.color}
      opacity={element.opacity}
      globalCompositeOperation={element.blend === 'multiply' ? 'multiply' : 'source-over'}
      perfectDrawEnabled={false}
      shadowForStrokeEnabled={false}
    />
  );
}

/** A named frame: a translucent tinted rounded rect + a border in the frame
 *  colour, with its label at the top-left. The filled rect is the hit target, so
 *  the frame is selectable in its empty areas while content on top stays clickable. */
function FrameVisual({ element }: { element: FrameElement }) {
  const { width, height, color } = element;
  return (
    <>
      <Rect
        width={width}
        height={height}
        cornerRadius={14}
        fill={color}
        opacity={0.08}
        perfectDrawEnabled={false}
      />
      <Rect
        width={width}
        height={height}
        cornerRadius={14}
        stroke={color}
        strokeWidth={1.5}
        opacity={0.55}
        fillEnabled={false}
        listening={false}
        perfectDrawEnabled={false}
      />
      <Text
        text={element.label || 'Frame'}
        x={12}
        y={10}
        fontSize={13}
        fontStyle="bold"
        fill={color}
        listening={false}
        perfectDrawEnabled={false}
      />
    </>
  );
}

/**
 * Renders an ImageElement as a real Konva Image node. While the signed URL is
 * being fetched (or the HTMLImageElement is loading), a skeleton placeholder is
 * shown so the bounding box / transformer remain in place. On error it falls
 * back to a labelled placeholder rather than disappearing.
 */
function ImageVisual({
  element,
  palette,
}: {
  element: ImageElement;
  palette: CanvasPalette;
}) {
  const { url, loading: urlLoading, error: urlError } = useSignedUrl(element.path);

  // Load the HTMLImageElement once the signed URL is ready. We keep it in state
  // so Konva can use it as its `image` prop — Konva requires the DOM object, not
  // just the src string.
  const [htmlImg, setHtmlImg] = useState<HTMLImageElement | null>(null);
  const [imgError, setImgError] = useState(false);

  useEffect(() => {
    // No synchronous setState in the effect body (react-hooks/set-state-in-effect):
    // htmlImg is only ever set from the async load callbacks below. A committed
    // image always has a path → url, so the null case is just "nothing to load yet".
    if (!url) return;
    let cancelled = false;
    const img = new window.Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      if (!cancelled) setHtmlImg(img);
    };
    img.onerror = () => {
      if (!cancelled) setImgError(true);
    };
    img.src = url;
    return () => {
      cancelled = true;
      img.onload = null;
      img.onerror = null;
    };
  }, [url]);

  const { width, height } = element;

  // ── Skeleton (URL loading or HTMLImage loading) ───────────────────────────
  if (urlLoading || (url && !htmlImg && !imgError)) {
    return (
      <>
        <Rect
          width={width}
          height={height}
          cornerRadius={16}
          fill={palette.surface}
          stroke={palette.border}
          strokeWidth={1}
          dash={[8, 6]}
          perfectDrawEnabled={false}
        />
        <Text
          text="Loading…"
          width={width}
          height={height}
          padding={12}
          fontSize={13}
          fontFamily="Inter, system-ui, sans-serif"
          fill={palette.text}
          align="center"
          verticalAlign="middle"
          listening={false}
        />
      </>
    );
  }

  // ── Error fallback ────────────────────────────────────────────────────────
  if (urlError || imgError || !htmlImg) {
    return (
      <>
        <Rect
          width={width}
          height={height}
          cornerRadius={16}
          fill={palette.surface}
          stroke={palette.border}
          strokeWidth={1}
          perfectDrawEnabled={false}
        />
        <Text
          text="⚠️  Image unavailable"
          width={width}
          height={height}
          padding={12}
          fontSize={14}
          fontFamily="Inter, system-ui, sans-serif"
          fill={palette.text}
          align="center"
          verticalAlign="middle"
          listening={false}
        />
      </>
    );
  }

  // ── Loaded ────────────────────────────────────────────────────────────────
  return (
    <KonvaImage
      image={htmlImg}
      width={width}
      height={height}
      cornerRadius={16}
      perfectDrawEnabled={false}
    />
  );
}
