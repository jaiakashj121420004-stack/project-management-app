import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

/** Merge class names, resolving conflicting Tailwind utilities sensibly. */
export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs));
}
