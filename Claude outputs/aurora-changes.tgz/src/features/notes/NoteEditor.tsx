import {
  lazy,
  Suspense,
  useCallback,
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
  type ChangeEvent,
} from 'react';
import { createPortal } from 'react-dom';
import { AlertCircle, ArrowLeft, Check, Download, Eye, FileText, FileType, Maximize2, Pencil, Trash2 } from 'lucide-react';
import type { JSONContent } from '@tiptap/core';
import { Spinner } from '@/components/feedback/Spinner';
import { RouteErrorBoundary } from '@/components/feedback/RouteErrorBoundary';
import { useAuth } from '@/hooks/useAuth';
import { useFocusHistory } from '@/features/canvas/useFocusHistory';
import { cn } from '@/lib/cn';
import { ShareButton } from '@/features/sharing';
import { EmojiPicker } from '@/components/forms/EmojiPicker';
import { SegmentedToggle } from '@/components/forms/SegmentedToggle';
import { ProGate, UpgradeModal } from '@/features/billing';
import { docToMarkdown } from '@/features/editor/serialize';
import { exportNoteAsDocx } from '@/features/editor/docxExport';
import { TemplatesMenu } from '@/features/editor/TemplatesMenu';
import { useSyncCustomTemplates } from '@/features/editor/useNoteTemplates';
import type { Note } from '@/types/database';
import { exportNoteAsPdf } from './exportNotePdf';
import { noteTitleSchema } from './schemas';

// The Tiptap block editor (+ markdown converter) is code-split — it loads only
// when a note is actually opened, so the notes routes stay light.
const NoteBlockEditor = lazy(() => import('./NoteBlockEditor'));

/** Autosave patch handler. Assignable from TanStack's `mutate`, so the same
 *  editor drives project notes AND standalone Library notes. */
export type UpdateNoteFn = (
  variables: {
    id: string;
    title?: string;
    icon?: string | null;
    cover?: string | null;
    content?: string;
    content_json?: Record<string, unknown> | null;
  },
  options?: { onSuccess?: (row: Note) => void; onError?: () => void },
) => void;
export type DeleteNoteFn = (variables: { id: string }) => void;

interface NoteEditorProps {
  /** Keyed by id in the parent, so this remounts (re-seeds) when the note changes. */
  note: Note;
  /** Editors/owners can edit + delete; viewers get a read-only rendered view. */
  canEdit: boolean;
  /** Clear the parent's selection after a delete (falls back to the next note). */
  onDeleted: () => void;
  /** Scoped autosave mutation (project- or library-keyed cache). */
  runUpdate: UpdateNoteFn;
  /** Scoped delete mutation. */
  runDelete: DeleteNoteFn;
}

type SaveStatus = 'saved' | 'unsaved' | 'saving' | 'error';

/** Debounced autosave: one write per ~700ms of idle, never on every keystroke. */
const AUTOSAVE_DELAY = 700;

/**
 * The note editor: an inline title, the shared Notion-style block editor, and a
 * subtle save indicator. Title and document edits autosave on a debounce and
 * flush on unmount, so switching notes never drops an in-flight change. The block
 * document is the source of truth (content_json); a plain-text mirror is saved
 * alongside for previews + search. Save status is derived during render.
 */
export function NoteEditor({ note, canEdit, onDeleted, runUpdate, runDelete }: NoteEditorProps) {
  const { user } = useAuth();
  // Keep the slash menu's "Your templates" section in sync with the user's saved
  // templates for the duration this editor is open.
  useSyncCustomTemplates();
  // A standalone note the current user owns can be shared with other users.
  const canShare = note.project_id === null && note.owner_id === user?.id;

  const [title, setTitle] = useState(note.title);
  const [savedTitle, setSavedTitle] = useState(note.title);
  const [docDirty, setDocDirty] = useState(false);
  // Edit/View toggle (editors only — a viewer already gets the read-only render
  // via `canEdit`, so this never applies to them).
  const [viewMode, setViewMode] = useState<'edit' | 'view'>('edit');
  const [saveState, setSaveState] = useState<'idle' | 'saving' | 'error'>('idle');
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  // Word (.docx) export — Pro. `exportingWord` disables the button mid-export
  // (asset fetch + rasterization can take a beat for an image/math-heavy
  // note); `wordUpgradeOpen` drives the upsell modal for a free user, since
  // this action gets its own compact ProGate `fallback` rather than the
  // default full-panel upsell (see the header row below).
  const [exportingWord, setExportingWord] = useState(false);
  const [wordUpgradeOpen, setWordUpgradeOpen] = useState(false);
  // PDF export — Pro. Same shape as the Word export state just above (its own
  // busy flag + its own upsell-modal flag, since each export gets its own
  // compact ProGate `fallback` icon button rather than the default full-panel
  // upsell — see the header row below).
  const [exportingPdf, setExportingPdf] = useState(false);
  const [pdfUpgradeOpen, setPdfUpgradeOpen] = useState(false);
  // Emoji icon (standalone Library notes only). Written immediately.
  const [icon, setIcon] = useState<string | null>(note.icon ?? null);
  const isStandalone = note.project_id === null;

  // Latest document from the editor (only present once the user edits).
  const docRef = useRef<{ json: JSONContent; text: string } | null>(null);

  const titleParse = noteTitleSchema.safeParse(title);
  const titleError = titleParse.success
    ? null
    : (titleParse.error.issues[0]?.message ?? 'Give the note a title.');
  const titleDirty = titleParse.success && titleParse.data !== savedTitle;
  const isDirty = titleDirty || docDirty;
  const status: SaveStatus =
    saveState === 'saving' ? 'saving' : saveState === 'error' ? 'error' : isDirty ? 'unsaved' : 'saved';

  const handleDocChange = useCallback((json: JSONContent, text: string) => {
    docRef.current = { json, text };
    setDocDirty(true);
  }, []);

  // Build the patch for whatever changed, or null if nothing (valid) has.
  const buildPatch = useCallback(() => {
    const patch: {
      id: string;
      title?: string;
      content?: string;
      content_json?: Record<string, unknown>;
    } = { id: note.id };
    if (titleParse.success && titleParse.data !== savedTitle) patch.title = titleParse.data;
    if (docDirty && docRef.current) {
      patch.content_json = docRef.current.json;
      patch.content = docRef.current.text;
    }
    return patch.title === undefined && patch.content_json === undefined ? null : patch;
  }, [note.id, titleParse, savedTitle, docDirty]);

  // Debounced autosave. setState only runs inside async callbacks.
  useEffect(() => {
    if (!canEdit || !isDirty) return;
    const timer = setTimeout(() => {
      const patch = buildPatch();
      if (!patch) return;
      setSaveState('saving');
      runUpdate(patch, {
        onSuccess: (row) => {
          setSavedTitle(row.title);
          setDocDirty(false);
          setSaveState('idle');
        },
        onError: () => setSaveState('error'),
      });
    }, AUTOSAVE_DELAY);
    return () => clearTimeout(timer);
  }, [canEdit, isDirty, buildPatch, runUpdate]);

  // Flush any pending change once on unmount (e.g. quickly switching notes).
  const flushRef = useRef<() => void>(() => {});
  useEffect(() => {
    flushRef.current = () => {
      if (!canEdit) return;
      const patch = buildPatch();
      if (patch) runUpdate(patch);
    };
  });
  useEffect(() => () => flushRef.current(), []);

  // Switching to View mid-edit should never strand an unsaved change — flush it
  // immediately, the same way an unmount does.
  function handleViewModeChange(next: 'edit' | 'view') {
    if (viewMode === 'edit' && next === 'view') flushRef.current();
    setViewMode(next);
  }

  // Notes open full screen (distraction-free); Exit or the device Back button
  // returns to the page chrome.
  const [focus, setFocus] = useState(true);
  const leaveFocus = useCallback(() => setFocus(false), []);
  const [host] = useState(() => {
    const el = document.createElement('div');
    el.className = 'flex flex-1 flex-col';
    return el;
  });
  const slotRef = useRef<HTMLDivElement>(null);
  useLayoutEffect(() => {
    const target = focus ? document.body : slotRef.current;
    target?.appendChild(host);
    return () => {
      host.remove();
    };
  }, [focus, host]);
  useFocusHistory(focus, leaveFocus);

  function handleDelete() {
    runDelete({ id: note.id });
    onDeleted();
  }

  function handleIconSelect(next: string | null) {
    setIcon(next);
    runUpdate({ id: note.id, icon: next });
  }

  // The note's current document, including unsaved edits — used by the export and
  // the "save as template" action so both capture what the user sees now.
  const currentDoc = (): JSONContent | null => docRef.current?.json ?? note.content_json;

  // Export the current document (including unsaved edits) as a .md download.
  function handleExport() {
    const doc = currentDoc();
    const cleanTitle = title.trim() || 'Untitled note';
    const markdown = `# ${cleanTitle}\n\n${docToMarkdown(doc)}`;
    const blob = new Blob([markdown], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `${cleanTitle.replace(/[^\w\- ]+/g, '').trim() || 'note'}.md`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
  }

  // Export the current document (including unsaved edits) as a real .docx
  // download — Pro-gated, see the <ProGate> around the toolbar button below.
  async function handleExportWord() {
    if (exportingWord) return;
    setExportingWord(true);
    try {
      await exportNoteAsDocx(currentDoc(), title);
    } catch {
      // Best-effort export — a failed fetch/rasterization step shouldn't crash
      // the editor. There's no dedicated error UI for this yet (matching the
      // existing Markdown export, which is likewise fire-and-forget); the
      // download simply doesn't happen.
    } finally {
      setExportingWord(false);
    }
  }

  // Export the current document (including unsaved edits) as a print-ready
  // PDF via the browser's native print-to-PDF (renders the note's existing
  // static HTML into a hidden iframe — see exportNotePdf.ts). Pro-gated, same
  // fire-and-forget-on-failure convention as the Markdown/Word exports above
  // (no dedicated error UI here either).
  async function handleExportPdf() {
    if (exportingPdf) return;
    setExportingPdf(true);
    try {
      await exportNoteAsPdf(currentDoc(), title);
    } catch {
      // See handleExportWord's comment — same convention, no error UI yet.
    } finally {
      setExportingPdf(false);
    }
  }

  const page = (
    <div
      className={cn(
        'flex flex-1 flex-col gap-4',
        focus && 'fixed inset-0 z-[80] overflow-y-auto bg-base px-4 pb-10 sm:px-[max(1rem,calc((100vw-62rem)/2))]',
      )}
      style={focus ? { paddingTop: 'max(0.75rem, env(safe-area-inset-top))' } : undefined}
    >
      {focus && (
        <div className="sticky top-0 z-20 -mx-1 flex items-center gap-2 py-1">
          <button
            type="button"
            onClick={leaveFocus}
            aria-label="Exit full screen"
            className="inline-flex h-11 items-center gap-2 rounded-2xl bg-[linear-gradient(110deg,var(--accent-from),var(--accent-to))] px-4 text-sm font-bold text-[var(--accent-fg)] shadow-[0_10px_26px_-10px_var(--accent-glow)] ring-1 ring-white/20 transition-transform hover:-translate-y-px active:translate-y-0"
          >
            <ArrowLeft size={18} />
            <span>Exit full screen</span>
          </button>
        </div>
      )}
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            {isStandalone && canEdit ? (
              <EmojiPicker
                value={icon}
                onSelect={handleIconSelect}
                ariaLabel="Set note icon"
                buttonClassName="h-9 w-9 shrink-0"
                iconSize={22}
              />
            ) : (
              icon && (
                <span className="grid h-9 w-9 shrink-0 place-items-center text-2xl leading-none">{icon}</span>
              )
            )}
            <input
              value={title}
              maxLength={120}
              readOnly={!canEdit}
              onChange={(event: ChangeEvent<HTMLInputElement>) => setTitle(event.target.value)}
              placeholder="Note title…"
              aria-label="Note title"
              className="min-w-0 flex-1 truncate bg-transparent font-display text-xl font-bold text-fg placeholder:text-fg-subtle focus:outline-none sm:text-2xl"
            />
          </div>
          {canEdit && titleError && <p className="mt-1 text-xs text-danger">{titleError}</p>}
        </div>

        <div className="flex shrink-0 items-center gap-2">
          {!focus && (
            <button
              type="button"
              aria-label="Full screen"
              title="Full screen"
              onClick={() => setFocus(true)}
              className="grid h-9 w-9 place-items-center rounded-xl text-fg-subtle transition-colors hover:bg-[var(--glass-fill)] hover:text-fg"
            >
              <Maximize2 size={16} />
            </button>
          )}
          <button
            type="button"
            aria-label="Export as Markdown"
            title="Export as Markdown"
            onClick={handleExport}
            className="grid h-9 w-9 place-items-center rounded-xl text-fg-subtle transition-colors hover:bg-[var(--glass-fill)] hover:text-fg"
          >
            <Download size={16} />
          </button>
          {/* Export as Word (.docx) — Pro. Sits next to Markdown export (and,
              once wired, PDF export/Task 35 — see exportNotePdf.ts) so every
              export format lives in one place. Uses ProGate's `fallback` prop
              (documented, previously-unused elsewhere in the app) to keep the
              same compact icon-button footprint for a free user instead of
              replacing it with the default full upsell panel. */}
          <ProGate
            title="Export to Word is a Pro feature"
            reason="Export your notes as polished .docx files, ready for Word, Google Docs, or LibreOffice."
            fallback={
              <button
                type="button"
                aria-label="Export as Word (Pro)"
                title="Export as Word — upgrade to Pro"
                onClick={() => setWordUpgradeOpen(true)}
                className="grid h-9 w-9 place-items-center rounded-xl text-fg-subtle transition-colors hover:bg-[var(--glass-fill)] hover:text-fg"
              >
                <FileType size={16} />
              </button>
            }
          >
            <button
              type="button"
              aria-label="Export as Word"
              title="Export as Word"
              onClick={() => void handleExportWord()}
              disabled={exportingWord}
              className="grid h-9 w-9 place-items-center rounded-xl text-fg-subtle transition-colors hover:bg-[var(--glass-fill)] hover:text-fg disabled:opacity-50"
            >
              {exportingWord ? <Spinner size={14} /> : <FileType size={16} />}
            </button>
          </ProGate>
          <UpgradeModal
            open={wordUpgradeOpen}
            onClose={() => setWordUpgradeOpen(false)}
            reason="Export your notes as Word documents."
          />
          {/* Export as PDF — Pro. Same compact ProGate `fallback` pattern as
              Word export just above (icon button in both the unlocked and
              locked state, rather than the default full-panel upsell). */}
          <ProGate
            title="PDF export is a Pro feature"
            reason="Export your notes as polished, print-ready PDFs — tables, math and images included."
            fallback={
              <button
                type="button"
                aria-label="Export as PDF (Pro)"
                title="Export as PDF — upgrade to Pro"
                onClick={() => setPdfUpgradeOpen(true)}
                className="grid h-9 w-9 place-items-center rounded-xl text-fg-subtle transition-colors hover:bg-[var(--glass-fill)] hover:text-fg"
              >
                <FileText size={16} />
              </button>
            }
          >
            <button
              type="button"
              aria-label="Export as PDF"
              title="Export as PDF"
              onClick={() => void handleExportPdf()}
              disabled={exportingPdf}
              className="grid h-9 w-9 place-items-center rounded-xl text-fg-subtle transition-colors hover:bg-[var(--glass-fill)] hover:text-fg disabled:opacity-50"
            >
              {exportingPdf ? <Spinner size={14} /> : <FileText size={16} />}
            </button>
          </ProGate>
          <UpgradeModal
            open={pdfUpgradeOpen}
            onClose={() => setPdfUpgradeOpen(false)}
            reason="Export your notes as polished, print-ready PDFs — tables, math and images included."
          />
          {/* Save-as-template + manager. Standalone notes only (personal, free). */}
          {isStandalone && canEdit && <TemplatesMenu getDoc={currentDoc} />}
          {canEdit && (
            <>
              {canShare && <ShareButton kind="note" targetId={note.id} title={note.title} />}
              <SaveIndicator status={status} />
              <button
                type="button"
                aria-label="Delete note"
                onClick={() => setConfirmingDelete((open) => !open)}
                className="grid h-9 w-9 place-items-center rounded-xl text-fg-subtle transition-colors hover:bg-danger/10 hover:text-danger"
              >
                <Trash2 size={16} />
              </button>
            </>
          )}
        </div>
      </div>

      {canEdit && (
        <SegmentedToggle
          label="Note mode"
          value={viewMode}
          onChange={handleViewModeChange}
          options={[
            { value: 'edit', label: 'Edit', icon: <Pencil size={14} /> },
            { value: 'view', label: 'View', icon: <Eye size={14} /> },
          ]}
        />
      )}

      {confirmingDelete && canEdit && (
        <div className="flex items-center justify-between gap-2 rounded-xl border border-danger/30 bg-danger/10 px-3 py-2 text-sm text-fg-muted">
          <span>
            Delete <span className="font-semibold text-fg">{note.title}</span>? This can&apos;t be
            undone.
          </span>
          <div className="flex shrink-0 items-center gap-1.5">
            <button
              type="button"
              onClick={() => setConfirmingDelete(false)}
              className="rounded-lg px-2 py-1 text-xs font-medium text-fg-muted hover:bg-[var(--glass-fill)]"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleDelete}
              className="rounded-lg bg-danger/20 px-2 py-1 text-xs font-semibold text-danger hover:bg-danger/30"
            >
              Delete
            </button>
          </div>
        </div>
      )}

      <RouteErrorBoundary key={note.id} label="the note editor" resetKeys={[note.id]}>
        <Suspense
          fallback={
            <div className="grid min-h-[40vh] place-items-center">
              <Spinner size={28} />
            </div>
          }
        >
          <NoteBlockEditor
            note={note}
            editable={canEdit && viewMode === 'edit'}
            onChange={handleDocChange}
          />
        </Suspense>
      </RouteErrorBoundary>
    </div>
  );

  // The page always renders into one detached host element that is MOVED between the
  // inline slot and <body>. A glass (backdrop-filter) ancestor would trap `fixed`, and
  // re-parenting the DOM node (instead of remounting) keeps the editor and any unsaved
  // text intact when toggling full screen.
  return (
    <>
      <div ref={slotRef} className="flex flex-1 flex-col" />
      {createPortal(page, host)}
    </>
  );
}

/** A subtle, non-shouting indicator of the autosave state. */
function SaveIndicator({ status }: { status: SaveStatus }) {
  if (status === 'saving') {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs text-fg-subtle">
        <Spinner size={12} className="text-current" /> Saving…
      </span>
    );
  }
  if (status === 'unsaved') {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs text-fg-subtle">
        <span className="h-1.5 w-1.5 rounded-full bg-warning" /> Unsaved
      </span>
    );
  }
  if (status === 'error') {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs text-danger">
        <AlertCircle size={13} /> Couldn&apos;t save
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1.5 text-xs text-fg-subtle">
      <Check size={13} className="text-success" /> Saved
    </span>
  );
}
