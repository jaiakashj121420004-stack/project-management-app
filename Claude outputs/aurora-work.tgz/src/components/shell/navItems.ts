import {
  BarChart3,
  CalendarDays,
  LayoutGrid,
  Library,
  ListTodo,
  Megaphone,
  MessageSquareHeart,
  Settings,
  Sunrise,
  type LucideIcon,
} from 'lucide-react';

export interface NavItem {
  label: string;
  to: string;
  icon: LucideIcon;
  /** Match the path exactly (for the index route). */
  end?: boolean;
  /** Also show in the mobile bottom bar (kept to the core destinations). */
  bottomNav?: boolean;
  /** Only render for the app administrator (gated by isAdminUser). */
  adminOnly?: boolean;
  /** Skip in the sidebar list (it has its own big button there). */
  sidebarHidden?: boolean;
}

/** Primary navigation. `bottomNav` items also appear in the mobile bottom bar. */
export const NAV_ITEMS: readonly NavItem[] = [
  { label: 'Today', to: '/today', icon: Sunrise, bottomNav: true },
  { label: 'Boards', to: '/boards', icon: LayoutGrid, end: true, bottomNav: true },
  { label: 'To-Do', to: '/todos', icon: ListTodo, bottomNav: true },
  { label: 'Calendar', to: '/calendar', icon: CalendarDays, bottomNav: true },
  { label: 'Notebooks', to: '/library', icon: Library, bottomNav: true, sidebarHidden: true },
  { label: 'From the Founder', to: '/from-the-founder', icon: Megaphone },
  { label: 'Feedback/Features', to: '/feedback', icon: MessageSquareHeart },
  { label: 'Analytics', to: '/analytics', icon: BarChart3, adminOnly: true },
  { label: 'Settings', to: '/settings', icon: Settings },
];
