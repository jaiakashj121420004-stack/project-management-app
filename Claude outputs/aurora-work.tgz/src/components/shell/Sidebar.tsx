import { AnimatePresence, motion } from 'framer-motion';
import { NavLink, useNavigate } from 'react-router-dom';
import { BookOpen, PanelLeftClose, PanelLeftOpen, Plus } from 'lucide-react';
import { Brand } from './Brand';
import { SidebarNav } from './SidebarNav';
import { GradientButton } from '@/components/buttons/GradientButton';
import { InstallPrompt } from '@/components/pwa/InstallPrompt';
import { useFocusTrap } from '@/hooks/useFocusTrap';
import { springs } from '@/lib/motion';
import { cn } from '@/lib/cn';

interface SidebarProps {
  collapsed: boolean;
  onToggleCollapsed: () => void;
  drawerOpen: boolean;
  onCloseDrawer: () => void;
}

/** Inner content shared by the desktop rail and the mobile drawer. */
function Inner({ collapsed, onNavigate }: { collapsed: boolean; onNavigate?: () => void }) {
  const navigate = useNavigate();

  function handleNewProject() {
    onNavigate?.();
    void navigate('/boards?new=1');
  }

  return (
    <div className="flex h-full flex-col gap-6 overflow-y-auto p-3">
      <div className={cn('px-1.5 pt-2', collapsed && 'flex justify-center px-0')}>
        <Brand collapsed={collapsed} />
      </div>

      <NavLink
        to="/library"
        onClick={onNavigate}
        title={collapsed ? 'Notebooks' : undefined}
        aria-label="Notebooks"
        className={({ isActive }) =>
          cn(
            'flex items-center justify-center gap-2.5 rounded-2xl border border-[var(--glass-border)]',
            'bg-[var(--glass-fill)] font-display text-lg font-semibold text-fg transition-colors',
            'hover:border-[color:var(--accent-from)]',
            collapsed ? 'aspect-square w-11 shrink-0 self-center' : 'w-full px-4 py-3',
            isActive && 'border-[color:var(--accent-from)] ring-2 ring-[var(--accent-from)]',
          )
        }
      >
        <BookOpen size={20} className="shrink-0" />
        {!collapsed && 'Notebooks'}
      </NavLink>

      <GradientButton
        size={collapsed ? 'sm' : 'lg'}
        leftIcon={<Plus size={20} />}
        onClick={handleNewProject}
        className={cn('w-full', collapsed && 'aspect-square w-11 shrink-0 px-0')}
        aria-label="New project"
      >
        {!collapsed && 'New project'}
      </GradientButton>

      <SidebarNav collapsed={collapsed} onNavigate={onNavigate} />

      <div className={cn('mt-auto flex flex-col gap-3 px-1.5', collapsed && 'items-center px-0')}>
        <InstallPrompt collapsed={collapsed} />

        <div className="text-xs leading-relaxed text-fg-subtle">
          {!collapsed && (
            <>
              <p>Aurora · v0.1 <span className="opacity-70">· by Nvexis</span></p>
              <p className="mt-0.5">
                Made by <span className="font-medium text-fg-muted">J. Jai Akash</span>
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

export function Sidebar({
  collapsed,
  onToggleCollapsed,
  drawerOpen,
  onCloseDrawer,
}: SidebarProps) {
  // Trap + restore focus inside the mobile drawer; Esc closes it.
  const drawerRef = useFocusTrap<HTMLElement>(drawerOpen, { onEscape: onCloseDrawer });

  return (
    <>
      {/* Desktop rail */}
      <aside
        className={cn(
          'glass relative z-20 hidden shrink-0 rounded-2xl transition-[width] duration-300 ease-spring md:block',
          collapsed ? 'w-[5.5rem]' : 'w-64',
        )}
      >
        <Inner collapsed={collapsed} />
        <button
          type="button"
          onClick={onToggleCollapsed}
          aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          className="glass absolute -right-3 top-7 grid h-7 w-7 place-items-center rounded-full text-fg-muted transition-colors hover:text-fg"
        >
          {collapsed ? <PanelLeftOpen size={15} /> : <PanelLeftClose size={15} />}
        </button>
      </aside>

      {/* Mobile drawer */}
      <AnimatePresence>
        {drawerOpen && (
          <div className="fixed inset-0 z-40 md:hidden">
            <motion.div
              className="absolute inset-0 bg-black/45 backdrop-blur-sm"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={onCloseDrawer}
            />
            <motion.aside
              ref={drawerRef}
              role="dialog"
              aria-modal="true"
              aria-label="Menu"
              tabIndex={-1}
              className="glass-strong absolute inset-y-0 left-0 w-72 rounded-r-2xl pb-[env(safe-area-inset-bottom)] pl-[env(safe-area-inset-left)] pt-[env(safe-area-inset-top)] outline-none"
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={springs.smooth}
            >
              <Inner collapsed={false} onNavigate={onCloseDrawer} />
            </motion.aside>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}
