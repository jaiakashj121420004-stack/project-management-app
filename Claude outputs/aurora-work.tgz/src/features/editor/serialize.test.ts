import { describe, it, expect } from 'vitest';
import {
  docToMarkdown,
  docToPlainText,
  emptyDoc,
  isEmptyDoc,
  markdownToDoc,
  renderBlockHtml,
  sanitizeBlockHtml,
} from './serialize';

describe('emptyDoc / isEmptyDoc', () => {
  it('emptyDoc is a doc with a single empty paragraph', () => {
    expect(emptyDoc()).toEqual({ type: 'doc', content: [{ type: 'paragraph' }] });
  });

  it('isEmptyDoc is true for an empty doc and for null', () => {
    expect(isEmptyDoc(emptyDoc())).toBe(true);
    expect(isEmptyDoc(null)).toBe(true);
  });

  it('isEmptyDoc is false once there is visible text', () => {
    expect(isEmptyDoc(markdownToDoc('hello'))).toBe(false);
  });
});

describe('docToPlainText', () => {
  it('joins block text with newlines and trims', () => {
    const doc = {
      type: 'doc',
      content: [
        { type: 'paragraph', content: [{ type: 'text', text: 'one' }] },
        { type: 'paragraph', content: [{ type: 'text', text: 'two' }] },
      ],
    };
    expect(docToPlainText(doc)).toBe('one\ntwo');
  });

  it('returns an empty string for a null body', () => {
    expect(docToPlainText(null)).toBe('');
  });
});

describe('renderBlockHtml', () => {
  it('returns an empty string for a null body', () => {
    expect(renderBlockHtml(null)).toBe('');
  });

  it('escapes HTML in text content (no raw injection)', () => {
    const doc = {
      type: 'doc',
      content: [{ type: 'paragraph', content: [{ type: 'text', text: '<script>alert(1)</script>' }] }],
    };
    const html = renderBlockHtml(doc);
    expect(html).not.toContain('<script>');
    expect(html).toContain('&lt;script&gt;');
  });

  it('never throws on a malformed body (returns a string)', () => {
    expect(typeof renderBlockHtml({ not: 'a real doc' })).toBe('string');
  });
});

describe('sanitizeBlockHtml (XSS defense-in-depth)', () => {
  it('strips <script> tags', () => {
    const out = sanitizeBlockHtml('<p>hi</p><script>alert(1)</script>');
    expect(out).toContain('hi');
    expect(out.toLowerCase()).not.toContain('<script');
  });

  it('strips inline event handlers', () => {
    const out = sanitizeBlockHtml('<p onclick="steal()">click</p>');
    expect(out).not.toContain('onclick');
    expect(out).toContain('click');
  });

  it('drops javascript: image sources and onerror payloads', () => {
    const out = sanitizeBlockHtml('<img src="x" onerror="alert(1)">');
    expect(out).not.toContain('onerror');
  });

  it('removes <iframe> and other active embeds', () => {
    const out = sanitizeBlockHtml('<iframe src="https://evil.test"></iframe><p>ok</p>');
    expect(out.toLowerCase()).not.toContain('<iframe');
    expect(out).toContain('ok');
  });

  it('preserves safe formatting, links (with target) and task checkboxes', () => {
    const html =
      '<a href="https://aurora.test" target="_blank" rel="noopener noreferrer nofollow">link</a>' +
      '<ul data-type="taskList"><li data-checked="true"><label><input type="checkbox" checked><span></span></label><div><p>task</p></div></li></ul>';
    const out = sanitizeBlockHtml(html);
    expect(out).toContain('href="https://aurora.test"');
    expect(out).toContain('target="_blank"');
    expect(out).toContain('type="checkbox"');
    expect(out).toContain('task');
  });

  it('is applied by renderBlockHtml (a tampered body yields no live markup)', () => {
    // A hand-crafted body that smuggles raw HTML into a text node. ProseMirror
    // escapes text nodes, so the "<img …>" becomes inert "&lt;img …&gt;" display
    // text; the DOMPurify pass is the second guarantee. Assert there is no LIVE
    // element (an escaped literal legitimately still contains the word "onerror"
    // as visible text — that's safe, so we check for an actual tag instead).
    const doc = {
      type: 'doc',
      content: [{ type: 'paragraph', content: [{ type: 'text', text: '<img src=x onerror=alert(1)>' }] }],
    };
    const out = renderBlockHtml(doc);
    expect(out).not.toContain('<img');
    expect(out).toContain('&lt;img'); // proof the dangerous markup was neutralised
  });
});

describe('renderBlockHtml (math formulas)', () => {
  it('renders an inline formula as real KaTeX markup, not an empty tag', () => {
    const doc = {
      type: 'doc',
      content: [
        {
          type: 'paragraph',
          content: [
            { type: 'text', text: 'Answer: ' },
            { type: 'mathInline', attrs: { latex: 'x^2' } },
          ],
        },
      ],
    };
    const html = renderBlockHtml(doc);
    // Regression guard: a math node missing from generateHTML's extension
    // list renders as an empty `<span data-math-inline=""></span>` — the
    // exact bug class just fixed for the Notes table block (an unknown/inert
    // node silently vanishing from the read-only view). Assert the actual
    // rendered formula markup is present, not just the wrapper tag.
    expect(html).toContain('data-math-inline');
    expect(html).toContain('class="katex"');
  });

  it('renders a block formula centred on its own line, with the data-latex source intact', () => {
    const doc = {
      type: 'doc',
      content: [{ type: 'mathBlock', attrs: { latex: 'x^2+y^2=z^2' } }],
    };
    const html = renderBlockHtml(doc);
    expect(html).toContain('data-math-block');
    expect(html).toContain('data-latex="x^2+y^2=z^2"');
    expect(html).toContain('class="katex"');
  });

  it('falls back to the raw LaTeX source (never throws) on invalid syntax', () => {
    const doc = {
      type: 'doc',
      content: [{ type: 'paragraph', content: [{ type: 'mathInline', attrs: { latex: '\\notarealcommand{' } }] }],
    };
    expect(() => renderBlockHtml(doc)).not.toThrow();
    const html = renderBlockHtml(doc);
    expect(html).toContain('math-render-error');
  });

  it('an empty formula renders no KaTeX markup (nothing to show yet)', () => {
    const doc = {
      type: 'doc',
      content: [{ type: 'paragraph', content: [{ type: 'mathInline', attrs: { latex: '' } }] }],
    };
    const html = renderBlockHtml(doc);
    expect(html).toContain('data-math-inline');
    expect(html).not.toContain('class="katex"');
  });

  it('survives the DOMPurify sanitize pass unchanged (KaTeX markup is not stripped)', () => {
    const doc = {
      type: 'doc',
      content: [{ type: 'paragraph', content: [{ type: 'mathInline', attrs: { latex: 'a+b' } }] }],
    };
    const rendered = renderBlockHtml(doc);
    expect(sanitizeBlockHtml(rendered)).toBe(rendered);
  });
});

describe('markdownToDoc', () => {
  it('yields an empty doc for empty input', () => {
    expect(markdownToDoc('')).toEqual(emptyDoc());
    expect(markdownToDoc('   ')).toEqual(emptyDoc());
  });

  it('parses a heading with its level', () => {
    const doc = markdownToDoc('## Title');
    const first = doc.content?.[0];
    expect(first?.type).toBe('heading');
    expect(first?.attrs?.level).toBe(2);
  });

  it('parses a task list with checked state', () => {
    const doc = markdownToDoc('- [x] done\n- [ ] todo');
    const list = doc.content?.[0];
    expect(list?.type).toBe('taskList');
    expect(list?.content?.[0]?.attrs?.checked).toBe(true);
    expect(list?.content?.[1]?.attrs?.checked).toBe(false);
  });

  it('parses inline bold marks', () => {
    const doc = markdownToDoc('a **bold** word');
    const marks = doc.content?.[0]?.content?.find((n) => n.text === 'bold')?.marks;
    expect(marks?.[0]?.type).toBe('bold');
  });
});

describe('docToMarkdown', () => {
  it('renders headings, bullets and inline marks', () => {
    const md = docToMarkdown(markdownToDoc('# Heading\n\n- item one\n- item two'));
    expect(md).toContain('# Heading');
    expect(md).toContain('- item one');
    expect(md).toContain('- item two');
  });

  it('returns an empty string for a null body', () => {
    expect(docToMarkdown(null)).toBe('');
  });

  it('round-trips a bold mark through markdown → doc → markdown', () => {
    const md = docToMarkdown(markdownToDoc('some **strong** text'));
    expect(md).toContain('**strong**');
  });
});
