export { GoalsPanel } from './GoalsPanel';
